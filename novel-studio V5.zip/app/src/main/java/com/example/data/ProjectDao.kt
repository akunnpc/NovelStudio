package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class ProjectWithCount(
    val id: Int,
    val title: String,
    val coverImageUri: String?,
    val totalChapterTarget: Int,
    val createdAt: Long,
    val chapterCount: Int
)

@Dao
interface ProjectDao {
    @Query("""
        SELECT p.id, p.title, p.coverImageUri, p.totalChapterTarget, p.createdAt, COUNT(c.id) as chapterCount 
        FROM projects p 
        LEFT JOIN chapters c ON p.id = c.projectId 
        GROUP BY p.id 
        ORDER BY p.createdAt DESC
    """)
    fun getAllProjectsWithCount(): Flow<List<ProjectWithCount>>

    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun getProjectById(id: Int): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectByIdOneShot(id: Int): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)
}
