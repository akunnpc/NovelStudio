package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.NovelStudioApplication
import com.example.ui.ViewModelFactory
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.projectdetail.ProjectDetailScreen
import com.example.ui.projectdetail.ProjectDetailViewModel
import com.example.ui.chapter.ChapterEditorScreen
import com.example.ui.chapter.ChapterViewModel
import com.example.ui.character.CharacterEditorScreen
import com.example.ui.character.CharacterViewModel
import com.example.ui.world.WorldEditorScreen
import com.example.ui.world.WorldViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel

@Composable
fun AppNavigation(
    navController: NavHostController,
    application: NovelStudioApplication,
    modifier: Modifier = Modifier
) {
    val factory = ViewModelFactory(
        application.projectRepository,
        application.chapterRepository,
        application.characterRepository,
        application.worldRepository,
        application.settingsRepository
    )

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = modifier
    ) {
        composable(Screen.Home.route) {
            val homeVm: HomeViewModel = viewModel(factory = factory)
            HomeScreen(
                viewModel = homeVm,
                onNavigateToProject = { projectId ->
                    navController.navigate(Screen.ProjectDetail.createRoute(projectId))
                },
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(
            route = Screen.ProjectDetail.route,
            arguments = listOf(navArgument("projectId") { type = NavType.IntType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getInt("projectId") ?: -1
            val detailVm: ProjectDetailViewModel = viewModel(factory = factory)
            ProjectDetailScreen(
                projectId = projectId,
                viewModel = detailVm,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToChapter = { chapterId ->
                    navController.navigate(Screen.ChapterEditor.createRoute(projectId, chapterId))
                },
                onNavigateToCharacter = { characterId ->
                    navController.navigate(Screen.CharacterEditor.createRoute(projectId, characterId))
                },
                onNavigateToWorld = { worldId ->
                    navController.navigate(Screen.WorldEditor.createRoute(projectId, worldId))
                }
            )
        }

        composable(
            route = Screen.ChapterEditor.route,
            arguments = listOf(
                navArgument("projectId") { type = NavType.IntType },
                navArgument("chapterId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getInt("projectId") ?: -1
            val chapterId = backStackEntry.arguments?.getInt("chapterId") ?: -1
            val chapterVm: ChapterViewModel = viewModel(factory = factory)
            ChapterEditorScreen(
                projectId = projectId,
                chapterId = chapterId,
                viewModel = chapterVm,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.CharacterEditor.route,
            arguments = listOf(
                navArgument("projectId") { type = NavType.IntType },
                navArgument("characterId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getInt("projectId") ?: -1
            val characterId = backStackEntry.arguments?.getInt("characterId") ?: -1
            val characterVm: CharacterViewModel = viewModel(factory = factory)
            CharacterEditorScreen(
                projectId = projectId,
                characterId = characterId,
                viewModel = characterVm,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.WorldEditor.route,
            arguments = listOf(
                navArgument("projectId") { type = NavType.IntType },
                navArgument("worldId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getInt("projectId") ?: -1
            val worldId = backStackEntry.arguments?.getInt("worldId") ?: -1
            val worldVm: WorldViewModel = viewModel(factory = factory)
            WorldEditorScreen(
                projectId = projectId,
                worldId = worldId,
                viewModel = worldVm,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            val settingsVm: SettingsViewModel = viewModel(factory = factory)
            SettingsScreen(
                viewModel = settingsVm,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
