package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StoryBibleDao {
    @Query("SELECT * FROM story_bible_entries WHERE projectId = :projectId ORDER BY title ASC")
    fun getStoryBibleForProject(projectId: Int): Flow<List<StoryBibleEntity>>

    @Query("SELECT * FROM story_bible_entries WHERE projectId = :projectId ORDER BY title ASC")
    suspend fun getStoryBibleForProjectOneShot(projectId: Int): List<StoryBibleEntity>

    @Query("SELECT * FROM story_bible_entries WHERE id = :id")
    fun getStoryBibleById(id: Int): Flow<StoryBibleEntity?>

    @Query("SELECT * FROM story_bible_entries WHERE id = :id")
    suspend fun getStoryBibleByIdOneShot(id: Int): StoryBibleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStoryBible(entry: StoryBibleEntity): Long

    @Update
    suspend fun updateStoryBible(entry: StoryBibleEntity)

    @Delete
    suspend fun deleteStoryBible(entry: StoryBibleEntity)
}
