package com.example.ui.storybible

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.StoryBibleEntity
import com.example.repository.StoryBibleRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class StoryBibleViewModel(
    private val repository: StoryBibleRepository
) : ViewModel() {

    private val _storyBibleState = MutableStateFlow<StoryBibleEntity?>(null)
    val storyBibleState: StateFlow<StoryBibleEntity?> = _storyBibleState

    fun loadStoryBibleEntry(id: Int) {
        if (id == -1) {
            _storyBibleState.value = null
            return
        }
        viewModelScope.launch {
            repository.getStoryBibleById(id).collect { entry ->
                _storyBibleState.value = entry
            }
        }
    }

    fun saveStoryBibleEntry(projectId: Int, id: Int, title: String, content: String, onDone: () -> Unit) {
        viewModelScope.launch {
            if (id == -1) {
                val newEntry = StoryBibleEntity(
                    projectId = projectId,
                    title = title,
                    content = content
                )
                repository.insertStoryBible(newEntry)
            } else {
                val existing = _storyBibleState.value
                if (existing != null) {
                    val updated = existing.copy(
                        title = title,
                        content = content
                    )
                    repository.updateStoryBible(updated)
                }
            }
            onDone()
        }
    }
}
