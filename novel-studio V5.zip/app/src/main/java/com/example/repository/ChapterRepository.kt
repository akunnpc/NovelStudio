package com.example.repository

import com.example.data.ChapterDao
import com.example.data.ChapterEntity
import kotlinx.coroutines.flow.Flow

class ChapterRepository(private val chapterDao: ChapterDao) {
    fun getChaptersForProject(projectId: Int): Flow<List<ChapterEntity>> =
        chapterDao.getChaptersForProject(projectId)

    fun getChapterById(id: Int): Flow<ChapterEntity?> = chapterDao.getChapterById(id)

    suspend fun getChapterByIdOneShot(id: Int): ChapterEntity? = chapterDao.getChapterByIdOneShot(id)

    fun getChapterCountForProject(projectId: Int): Flow<Int> =
        chapterDao.getChapterCountForProject(projectId)

    suspend fun getMaxChapterNumber(projectId: Int): Int? = chapterDao.getMaxChapterNumber(projectId)

    suspend fun insertChapter(chapter: ChapterEntity): Long = chapterDao.insertChapter(chapter)

    suspend fun updateChapter(chapter: ChapterEntity) = chapterDao.updateChapter(chapter)

    suspend fun deleteChapter(chapter: ChapterEntity) = chapterDao.deleteChapter(chapter)
}
