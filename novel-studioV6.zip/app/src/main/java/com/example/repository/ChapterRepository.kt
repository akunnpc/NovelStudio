package com.example.repository

import com.example.data.ChapterDao
import com.example.data.ChapterEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class ChapterRepository(
    private val chapterDao: ChapterDao,
    private val aiRepository: AiRepository
) {
    private val repositoryScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO
    )

    fun generateSummaryInBackground(chapterId: Int, content: String) {
        repositoryScope.launch {
            try {
                // Update summary status to "PENDING"
                val existing = getChapterByIdOneShot(chapterId)
                if (existing != null) {
                    updateChapter(existing.copy(summary = "PENDING"))
                }

                val prompt = """
                    Summarize the following novel chapter.
                    Rules:
                    - Maximum 3 sentences.
                    - Mention only important plot events.
                    - Mention important character changes.
                    - Mention location changes.
                    - Do not add new information.
                    - Keep the summary factual.

                    Chapter Content:
                    $content
                """.trimIndent()

                val response = aiRepository.generateStoryResponse(
                    prompt = prompt,
                    systemInstruction = "You are a helpful assistant that generates extremely concise factual chapter summaries."
                )

                val finalSummary = if (response.startsWith("Error") || response.startsWith("Gagal terhubung")) {
                    android.util.Log.e("ChapterRepository", "Summary generation failed API response: $response")
                    "FAILED"
                } else {
                    response.trim()
                }

                val updated = getChapterByIdOneShot(chapterId)
                if (updated != null) {
                    updateChapter(updated.copy(summary = finalSummary))
                }
            } catch (e: Exception) {
                android.util.Log.e("ChapterRepository", "Exception during summary generation", e)
                val updated = getChapterByIdOneShot(chapterId)
                if (updated != null) {
                    updateChapter(updated.copy(summary = "FAILED"))
                }
            }
        }
    }

    suspend fun getChapterSummariesForProjectOneShot(projectId: Int): List<com.example.data.ChapterSummary> =
        chapterDao.getChapterSummariesForProjectOneShot(projectId)

    fun getChaptersForProject(projectId: Int): Flow<List<ChapterEntity>> =
        chapterDao.getChaptersForProject(projectId)

    fun getChapterById(id: Int): Flow<ChapterEntity?> = chapterDao.getChapterById(id)

    suspend fun getChapterByIdOneShot(id: Int): ChapterEntity? = chapterDao.getChapterByIdOneShot(id)

    fun getChapterCountForProject(projectId: Int): Flow<Int> =
        chapterDao.getChapterCountForProject(projectId)

    suspend fun getMaxChapterNumber(projectId: Int): Int? = chapterDao.getMaxChapterNumber(projectId)

    suspend fun insertChapter(chapter: ChapterEntity): Long = chapterDao.insertChapter(chapter)

    suspend fun updateChapter(chapter: ChapterEntity) = chapterDao.updateChapter(chapter)

    suspend fun deleteChapter(chapter: ChapterEntity) = chapterDao.deleteChapter(chapter)
}
