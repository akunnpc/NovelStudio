package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectEntity
import com.example.data.ProjectWithCount
import com.example.repository.ProjectRepository
import com.example.repository.SettingsRepository
import com.example.repository.AiRepository
import com.example.ui.projectdetail.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repository: ProjectRepository,
    private val settingsRepository: SettingsRepository,
    private val aiRepository: AiRepository
) : ViewModel() {

    val projects: StateFlow<List<ProjectWithCount>> = repository.allProjectsWithCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val aiApiKey: StateFlow<String> = settingsRepository.apiKey
    val aiBaseUrl: StateFlow<String> = settingsRepository.baseUrl
    val aiModelName: StateFlow<String> = settingsRepository.modelName

    // Global Chat states
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading

    fun addProject(title: String, coverImageUri: String?, totalChapterTarget: Int) {
        viewModelScope.launch {
            repository.insertProject(
                ProjectEntity(
                    title = title,
                    coverImageUri = coverImageUri,
                    totalChapterTarget = if (totalChapterTarget <= 0) 1 else totalChapterTarget
                )
            )
        }
    }

    fun deleteProject(id: Int) {
        viewModelScope.launch {
            val project = repository.getProjectByIdOneShot(id)
            if (project != null) {
                repository.deleteProject(project)
            }
        }
    }

    fun sendChatMessage(message: String) {
        if (message.isBlank()) return

        val userMessage = ChatMessage(role = "user", content = message)
        _chatHistory.value = _chatHistory.value + userMessage
        _isAiLoading.value = true

        val systemInst = "Anda adalah asisten AI Novel Studio, asisten kreatif penulisan cerita berbahasa Indonesia."

        viewModelScope.launch {
            val response = aiRepository.generateStoryResponse(message, systemInst)
            _chatHistory.value = _chatHistory.value + ChatMessage(role = "assistant", content = response)
            _isAiLoading.value = false
        }
    }

    fun clearChat() {
        _chatHistory.value = emptyList()
    }
}
