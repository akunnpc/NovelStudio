package com.example.ui.chapter

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterEditorScreen(
    projectId: Int,
    chapterId: Int,
    viewModel: ChapterViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(chapterId) {
        viewModel.loadChapter(chapterId)
    }

    val chapter by viewModel.chapterState.collectAsState()

    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    // Synchronize title and content from loaded chapter
    LaunchedEffect(chapter) {
        chapter?.let {
            title = it.title
            content = it.content
        } ?: run {
            title = ""
            content = ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (chapterId == -1) "Arsip Bab Baru" else "Edit Arsip Bab",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            viewModel.saveChapter(projectId, chapterId, title, content) {
                                onNavigateBack()
                            }
                        },
                        modifier = Modifier.testTag("save_chapter_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Simpan")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Judul Bab (contoh: Pertemuan Pertama)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("chapter_title_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("Konten Tulisan Bab") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 350.dp)
                    .testTag("chapter_content_input"),
                singleLine = false,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}
