package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WorldDao {
    @Query("SELECT * FROM world_entries WHERE projectId = :projectId ORDER BY title ASC")
    fun getWorldEntriesForProject(projectId: Int): Flow<List<WorldEntity>>

    @Query("SELECT * FROM world_entries WHERE id = :id")
    fun getWorldEntryById(id: Int): Flow<WorldEntity?>

    @Query("SELECT * FROM world_entries WHERE id = :id")
    suspend fun getWorldEntryByIdOneShot(id: Int): WorldEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorldEntry(worldEntry: WorldEntity): Long

    @Update
    suspend fun updateWorldEntry(worldEntry: WorldEntity)

    @Delete
    suspend fun deleteWorldEntry(worldEntry: WorldEntity)
}
