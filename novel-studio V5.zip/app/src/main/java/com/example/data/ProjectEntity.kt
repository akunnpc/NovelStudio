package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val coverImageUri: String?,
    val totalChapterTarget: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val genre: String = "",
    val subGenre: String = "",
    val tone: String = "",
    val writingStyle: String = "",
    val pov: String = "",
    val targetAudience: String = "",
    val language: String = "",
    val tense: String = "",
    val targetPlatform: String = ""
)
