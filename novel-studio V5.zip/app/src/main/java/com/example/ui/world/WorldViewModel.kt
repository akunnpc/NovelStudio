package com.example.ui.world

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.WorldEntity
import com.example.repository.WorldRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class WorldViewModel(
    private val repository: WorldRepository
) : ViewModel() {

    private val _worldState = MutableStateFlow<WorldEntity?>(null)
    val worldState: StateFlow<WorldEntity?> = _worldState

    fun loadWorldEntry(worldId: Int) {
        if (worldId == -1) {
            _worldState.value = null
            return
        }
        viewModelScope.launch {
            repository.getWorldEntryById(worldId).collect { entry ->
                _worldState.value = entry
            }
        }
    }

    fun saveWorldEntry(projectId: Int, worldId: Int, title: String, content: String, onDone: () -> Unit) {
        viewModelScope.launch {
            if (worldId == -1) {
                val newEntry = WorldEntity(
                    projectId = projectId,
                    title = title,
                    content = content
                )
                repository.insertWorldEntry(newEntry)
            } else {
                val existing = _worldState.value
                if (existing != null) {
                    val updated = existing.copy(
                        title = title,
                        content = content
                    )
                    repository.updateWorldEntry(updated)
                }
            }
            onDone()
        }
    }
}
