package com.example.repository

import com.example.repository.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AiRepository(private val settingsRepository: SettingsRepository) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateStoryResponse(prompt: String, systemInstruction: String? = null): String {
        return withContext(Dispatchers.IO) {
            try {
                val apiKey = settingsRepository.apiKey.value
                val baseUrl = settingsRepository.baseUrl.value
                val modelName = settingsRepository.modelName.value

                val isGemini = baseUrl.contains("googleapis.com") || modelName.startsWith("gemini")

                val endpoint = if (isGemini) {
                    val baseWithSlash = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
                    "${baseWithSlash}models/${modelName}:generateContent?key=${apiKey}"
                } else {
                    val baseWithSlash = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
                    "${baseWithSlash}chat/completions"
                }

                val jsonPayload = if (isGemini) {
                    JSONObject().apply {
                        put("contents", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("parts", org.json.JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("text", prompt)
                                    })
                                })
                            })
                        })
                        if (!systemInstruction.isNullOrBlank()) {
                            put("systemInstruction", JSONObject().apply {
                                put("parts", org.json.JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("text", systemInstruction)
                                    })
                                })
                            })
                        }
                    }.toString()
                } else {
                    JSONObject().apply {
                        put("model", modelName)
                        put("messages", org.json.JSONArray().apply {
                            if (!systemInstruction.isNullOrBlank()) {
                                put(JSONObject().apply {
                                    put("role", "system")
                                    put("content", systemInstruction)
                                })
                            }
                            put(JSONObject().apply {
                                put("role", "user")
                                put("content", prompt)
                            })
                        })
                    }.toString()
                }

                val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
                val requestBody = jsonPayload.toRequestBody(mediaType)

                val requestBuilder = Request.Builder()
                    .url(endpoint)
                    .addHeader("Content-Type", "application/json")

                if (!isGemini && apiKey.isNotBlank()) {
                    requestBuilder.addHeader("Authorization", "Bearer $apiKey")
                }

                val request = requestBuilder.post(requestBody).build()

                client.newCall(request).execute().use { response ->
                    val bodyString = response.body?.string()
                    if (response.isSuccessful && bodyString != null) {
                        if (isGemini) {
                            val json = JSONObject(bodyString)
                            val candidates = json.getJSONArray("candidates")
                            val firstCandidate = candidates.getJSONObject(0)
                            val contentObj = firstCandidate.getJSONObject("content")
                            val parts = contentObj.getJSONArray("parts")
                            parts.getJSONObject(0).getString("text")
                        } else {
                            val json = JSONObject(bodyString)
                            val choices = json.getJSONArray("choices")
                            val message = choices.getJSONObject(0).getJSONObject("message")
                            message.getString("content")
                        }
                    } else {
                        "Error ${response.code}: ${response.message}\nDetail: $bodyString"
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                "Gagal terhubung dengan API: ${e.localizedMessage ?: "Unknown Error"}"
            }
        }
    }
}
