package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object ProjectDetail : Screen("project_detail/{projectId}") {
        fun createRoute(projectId: Int) = "project_detail/$projectId"
    }
    object ChapterEditor : Screen("chapter_editor/{projectId}/{chapterId}") {
        fun createRoute(projectId: Int, chapterId: Int) = "chapter_editor/$projectId/$chapterId"
    }
    object CharacterEditor : Screen("character_editor/{projectId}/{characterId}") {
        fun createRoute(projectId: Int, characterId: Int) = "character_editor/$projectId/$characterId"
    }
    object WorldEditor : Screen("world_editor/{projectId}/{worldId}") {
        fun createRoute(projectId: Int, worldId: Int) = "world_editor/$projectId/$worldId"
    }
    object Settings : Screen("settings")
}
