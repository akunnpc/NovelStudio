package com.example.ui.world

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldEditorScreen(
    projectId: Int,
    worldId: Int,
    viewModel: WorldViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(worldId) {
        viewModel.loadWorldEntry(worldId)
    }

    val worldEntry by viewModel.worldState.collectAsState()

    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    // Synchronize states
    LaunchedEffect(worldEntry) {
        worldEntry?.let {
            title = it.title
            content = it.content
        } ?: run {
            title = ""
            content = ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (worldId == -1) "Catatan Dunia Baru" else "Edit Catatan Dunia",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                viewModel.saveWorldEntry(projectId, worldId, title, content) {
                                    onNavigateBack()
                                }
                            }
                        },
                        enabled = title.isNotBlank(),
                        modifier = Modifier.testTag("save_world_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Simpan")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Nama Latar / Garis Waktu / Legenda") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("world_title_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("Deskripsi Detail Catatan Latar Belakang Cerita") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 350.dp)
                    .testTag("world_content_input"),
                singleLine = false,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}
