package com.example.repository

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SettingsRepository(context: Context) {
    private val sharedPrefs = context.getSharedPreferences("novel_studio_settings", Context.MODE_PRIVATE)

    private val _apiKey = MutableStateFlow(sharedPrefs.getString("api_key", "") ?: "")
    val apiKey: StateFlow<String> = _apiKey

    private val _baseUrl = MutableStateFlow(sharedPrefs.getString("base_url", "https://api.openai.com/v1/") ?: "https://api.openai.com/v1/")
    val baseUrl: StateFlow<String> = _baseUrl

    fun saveSettings(key: String, url: String) {
        sharedPrefs.edit()
            .putString("api_key", key)
            .putString("base_url", url)
            .apply()
        _apiKey.value = key
        _baseUrl.value = url
    }
}
