package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.repository.ChapterRepository
import com.example.repository.CharacterRepository
import com.example.repository.ProjectRepository
import com.example.repository.SettingsRepository
import com.example.repository.WorldRepository
import com.example.repository.AiRepository
import com.example.repository.StoryBibleRepository
import com.example.repository.StoryContextComposer
import com.example.ui.home.HomeViewModel
import com.example.ui.projectdetail.ProjectDetailViewModel
import com.example.ui.chapter.ChapterViewModel
import com.example.ui.character.CharacterViewModel
import com.example.ui.world.WorldViewModel
import com.example.ui.storybible.StoryBibleViewModel
import com.example.ui.settings.SettingsViewModel

class ViewModelFactory(
    private val projectRepository: ProjectRepository,
    private val chapterRepository: ChapterRepository,
    private val characterRepository: CharacterRepository,
    private val worldRepository: WorldRepository,
    private val settingsRepository: SettingsRepository,
    private val aiRepository: AiRepository,
    private val storyBibleRepository: StoryBibleRepository,
    private val storyContextComposer: StoryContextComposer
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> {
                HomeViewModel(projectRepository, settingsRepository, aiRepository) as T
            }
            modelClass.isAssignableFrom(ProjectDetailViewModel::class.java) -> {
                ProjectDetailViewModel(
                    projectRepository,
                    chapterRepository,
                    characterRepository,
                    worldRepository,
                    settingsRepository,
                    aiRepository,
                    storyBibleRepository,
                    storyContextComposer
                ) as T
            }
            modelClass.isAssignableFrom(ChapterViewModel::class.java) -> {
                ChapterViewModel(chapterRepository) as T
            }
            modelClass.isAssignableFrom(CharacterViewModel::class.java) -> {
                CharacterViewModel(characterRepository) as T
            }
            modelClass.isAssignableFrom(WorldViewModel::class.java) -> {
                WorldViewModel(worldRepository) as T
            }
            modelClass.isAssignableFrom(StoryBibleViewModel::class.java) -> {
                StoryBibleViewModel(storyBibleRepository) as T
            }
            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> {
                SettingsViewModel(settingsRepository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
