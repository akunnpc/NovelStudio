package com.example.repository

import com.example.data.CharacterEntity
import com.example.data.WorldEntity
import com.example.data.StoryBibleEntity

class StoryContextComposer(
    private val characterRepository: CharacterRepository,
    private val worldRepository: WorldRepository,
    private val storyBibleRepository: StoryBibleRepository,
    private val chapterRepository: ChapterRepository
) {

    private fun matchesKeyword(prompt: String, keyword: String): Boolean {
        if (keyword.isBlank()) return false
        val regex = Regex("\\b${Regex.escape(keyword)}\\b", RegexOption.IGNORE_CASE)
        return regex.containsMatchIn(prompt)
    }

    private fun truncateContent(text: String, maxLength: Int = 400): String {
        return if (text.length > maxLength) {
            text.take(maxLength) + "..."
        } else {
            text
        }
    }

    suspend fun composeStoryMemory(projectId: Int, prompt: String): String {
        if (projectId == -1) return ""

        val allCharacters = characterRepository.getCharactersForProjectOneShot(projectId)
        val allWorlds = worldRepository.getWorldEntriesForProjectOneShot(projectId)
        val allStoryBibles = storyBibleRepository.getStoryBibleForProjectOneShot(projectId)
        val allSummaries = chapterRepository.getChapterSummariesForProjectOneShot(projectId)

        val matchedCharacters = allCharacters.filter { char ->
            matchesKeyword(prompt, char.name) || (!char.alias.isNullOrBlank() && matchesKeyword(prompt, char.alias))
        }.take(3)

        val matchedWorlds = allWorlds.filter { world ->
            matchesKeyword(prompt, world.title)
        }.take(2)

        val matchedStoryBibles = allStoryBibles.filter { bible ->
            matchesKeyword(prompt, bible.title)
        }.take(2)

        val validSummaries = allSummaries.filter {
            !it.summary.isNullOrBlank() && it.summary != "PENDING" && it.summary != "FAILED"
        }
        val last5Summaries = validSummaries.takeLast(5)
        val selectedSummaries = mutableListOf<com.example.data.ChapterSummary>()
        var currentLength = 0
        for (cs in last5Summaries.reversed()) {
            val line = "- Bab ${cs.chapterNumber}: ${cs.title} -> ${cs.summary}\n"
            if (currentLength + line.length <= 2000) {
                selectedSummaries.add(0, cs)
                currentLength += line.length
            } else {
                break
            }
        }

        if (matchedCharacters.isEmpty() && matchedWorlds.isEmpty() && matchedStoryBibles.isEmpty() && selectedSummaries.isEmpty()) {
            return ""
        }

        val builder = java.lang.StringBuilder()
        builder.append("=== MEMORI CERITA RELEVAN (STORY BIBLE & LORE) ===\n")

        if (matchedCharacters.isNotEmpty()) {
            builder.append("\nKarakter Terkait:\n")
            matchedCharacters.forEach { char ->
                val aliasStr = if (!char.alias.isNullOrBlank()) " (${char.alias})" else ""
                builder.append("- ${char.name}$aliasStr: ${truncateContent(char.description)}\n")
            }
        }

        if (matchedWorlds.isNotEmpty()) {
            builder.append("\nSetting/Dunia Terkait:\n")
            matchedWorlds.forEach { world ->
                builder.append("- ${world.title}: ${truncateContent(world.content)}\n")
            }
        }

        if (matchedStoryBibles.isNotEmpty()) {
            builder.append("\nAturan/Lore Alkitab Cerita Terkait:\n")
            matchedStoryBibles.forEach { bible ->
                builder.append("- ${bible.title}: ${truncateContent(bible.content)}\n")
            }
        }

        if (selectedSummaries.isNotEmpty()) {
            builder.append("\nRingkasan Bab Terdahulu:\n")
            selectedSummaries.forEach { cs ->
                builder.append("- Bab ${cs.chapterNumber}: ${cs.title} -> ${cs.summary}\n")
            }
        }

        builder.append("\n==================================================\n")

        val result = builder.toString()
        return if (result.length > 2000) {
            result.take(1997) + "..."
        } else {
            result
        }
    }
}
