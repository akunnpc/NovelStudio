package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class ChapterSummary(
    val id: Int,
    val chapterNumber: Int,
    val title: String,
    val summary: String?
)

@Dao
interface ChapterDao {
    @Query("SELECT id, chapterNumber, title, summary FROM chapters WHERE projectId = :projectId ORDER BY chapterNumber ASC")
    suspend fun getChapterSummariesForProjectOneShot(projectId: Int): List<ChapterSummary>

    @Query("SELECT * FROM chapters WHERE projectId = :projectId ORDER BY chapterNumber ASC")
    fun getChaptersForProject(projectId: Int): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE id = :id")
    fun getChapterById(id: Int): Flow<ChapterEntity?>

    @Query("SELECT * FROM chapters WHERE id = :id")
    suspend fun getChapterByIdOneShot(id: Int): ChapterEntity?

    @Query("SELECT COUNT(*) FROM chapters WHERE projectId = :projectId")
    fun getChapterCountForProject(projectId: Int): Flow<Int>

    @Query("SELECT MAX(chapterNumber) FROM chapters WHERE projectId = :projectId")
    suspend fun getMaxChapterNumber(projectId: Int): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Delete
    suspend fun deleteChapter(chapter: ChapterEntity)
}
