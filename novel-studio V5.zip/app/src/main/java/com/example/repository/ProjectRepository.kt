package com.example.repository

import com.example.data.ProjectDao
import com.example.data.ProjectEntity
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()
    val allProjectsWithCount = projectDao.getAllProjectsWithCount()

    fun getProjectById(id: Int): Flow<ProjectEntity?> = projectDao.getProjectById(id)

    suspend fun getProjectByIdOneShot(id: Int): ProjectEntity? = projectDao.getProjectByIdOneShot(id)

    suspend fun insertProject(project: ProjectEntity): Long = projectDao.insertProject(project)

    suspend fun updateProject(project: ProjectEntity) = projectDao.updateProject(project)

    suspend fun deleteProject(project: ProjectEntity) = projectDao.deleteProject(project)
}
