package com.example.repository

import com.example.data.StoryBibleDao
import com.example.data.StoryBibleEntity
import kotlinx.coroutines.flow.Flow

class StoryBibleRepository(private val storyBibleDao: StoryBibleDao) {
    fun getStoryBibleForProject(projectId: Int): Flow<List<StoryBibleEntity>> =
        storyBibleDao.getStoryBibleForProject(projectId)

    suspend fun getStoryBibleForProjectOneShot(projectId: Int): List<StoryBibleEntity> =
        storyBibleDao.getStoryBibleForProjectOneShot(projectId)

    fun getStoryBibleById(id: Int): Flow<StoryBibleEntity?> = storyBibleDao.getStoryBibleById(id)

    suspend fun getStoryBibleByIdOneShot(id: Int): StoryBibleEntity? = storyBibleDao.getStoryBibleByIdOneShot(id)

    suspend fun insertStoryBible(entry: StoryBibleEntity): Long = storyBibleDao.insertStoryBible(entry)

    suspend fun updateStoryBible(entry: StoryBibleEntity) = storyBibleDao.updateStoryBible(entry)

    suspend fun deleteStoryBible(entry: StoryBibleEntity) = storyBibleDao.deleteStoryBible(entry)
}
