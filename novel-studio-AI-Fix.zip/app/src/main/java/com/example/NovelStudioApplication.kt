package com.example

import android.app.Application
import com.example.data.AppDatabase
import com.example.repository.ChapterRepository
import com.example.repository.CharacterRepository
import com.example.repository.ProjectRepository
import com.example.repository.SettingsRepository
import com.example.repository.WorldRepository

class NovelStudioApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    
    val projectRepository by lazy { ProjectRepository(database.projectDao()) }
    val chapterRepository by lazy { ChapterRepository(database.chapterDao()) }
    val characterRepository by lazy { CharacterRepository(database.characterDao()) }
    val worldRepository by lazy { WorldRepository(database.worldDao()) }
    val settingsRepository by lazy { SettingsRepository(this) }
}
