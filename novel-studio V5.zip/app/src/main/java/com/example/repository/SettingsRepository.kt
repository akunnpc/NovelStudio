package com.example.repository

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SettingsRepository(context: Context) {
    private val sharedPrefs = context.getSharedPreferences("novel_studio_settings", Context.MODE_PRIVATE)

    private val _apiKey = MutableStateFlow(sharedPrefs.getString("api_key", "") ?: "")
    val apiKey: StateFlow<String> = _apiKey

    private val _baseUrl = MutableStateFlow(sharedPrefs.getString("base_url", "https://api.openai.com/v1/") ?: "https://api.openai.com/v1/")
    val baseUrl: StateFlow<String> = _baseUrl

    private val _modelName = MutableStateFlow(sharedPrefs.getString("model_name", "gemini-2.0-flash") ?: "gemini-2.0-flash")
    val modelName: StateFlow<String> = _modelName

    fun saveSettings(key: String, url: String, model: String) {
        sharedPrefs.edit()
            .putString("api_key", key)
            .putString("base_url", url)
            .putString("model_name", model)
            .apply()
        _apiKey.value = key
        _baseUrl.value = url
        _modelName.value = model
    }
}
