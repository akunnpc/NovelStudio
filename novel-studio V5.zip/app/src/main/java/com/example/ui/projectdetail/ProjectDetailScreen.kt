package com.example.ui.projectdetail

import kotlinx.coroutines.launch

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChapterEntity
import com.example.data.CharacterEntity
import com.example.data.WorldEntity
import com.example.data.StoryBibleEntity
import com.example.data.ProjectEntity
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.MenuBook
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    projectId: Int,
    viewModel: ProjectDetailViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToChapter: (Int) -> Unit, // passes chapterId
    onNavigateToCharacter: (Int) -> Unit, // passes characterId
    onNavigateToWorld: (Int) -> Unit, // passes worldId
    onNavigateToStoryBible: (Int) -> Unit, // passes storyBibleId
    onNavigateToAiChat: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(projectId) {
        viewModel.setProjectId(projectId)
    }

    val project by viewModel.project.collectAsState()
    val chapters by viewModel.chapters.collectAsState()
    val characters by viewModel.characters.collectAsState()
    val worldEntries by viewModel.worldEntries.collectAsState()
    val storyBibleEntries by viewModel.storyBibleEntries.collectAsState()
    val apiKey by viewModel.aiApiKey.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }

    val hasApiKey = apiKey.isNotBlank()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = project?.title ?: "Memuat...",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    if (hasApiKey) {
                        IconButton(
                            onClick = { onNavigateToAiChat(projectId) },
                            modifier = Modifier.testTag("ai_assistant_toggle")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Asisten AI",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Chapter", fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.Book, contentDescription = null) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Karakter", fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.Face, contentDescription = null) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("World", fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.Map, contentDescription = null) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("Alkitab", fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.MenuBook, contentDescription = null) }
                    )
                    Tab(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        text = { Text("Konteks", fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) }
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (selectedTab) {
                        0 -> ChapterSection(
                            chapters = chapters,
                            onAddChapter = { onNavigateToChapter(-1) },
                            onEditChapter = { onNavigateToChapter(it) },
                            onDeleteChapter = { viewModel.deleteChapter(it) }
                        )
                        1 -> CharacterSection(
                            characters = characters,
                            onAddCharacter = { onNavigateToCharacter(-1) },
                            onEditCharacter = { onNavigateToCharacter(it) },
                            onDeleteCharacter = { viewModel.deleteCharacter(it) }
                        )
                        2 -> WorldSection(
                            worldEntries = worldEntries,
                            onAddWorld = { onNavigateToWorld(-1) },
                            onEditWorld = { onNavigateToWorld(it) },
                            onDeleteWorld = { viewModel.deleteWorldEntry(it) }
                        )
                        3 -> StoryBibleSection(
                            storyBibleEntries = storyBibleEntries,
                            onAddStoryBible = { onNavigateToStoryBible(-1) },
                            onEditStoryBible = { onNavigateToStoryBible(it) },
                            onDeleteStoryBible = { viewModel.deleteStoryBibleEntry(it) }
                        )
                        4 -> ContextProfileSection(
                            project = project,
                            onSave = { genre, subGenre, tone, writingStyle, pov, targetAudience, language, tense, targetPlatform ->
                                viewModel.updateProjectContext(
                                    genre = genre,
                                    subGenre = subGenre,
                                    tone = tone,
                                    writingStyle = writingStyle,
                                    pov = pov,
                                    targetAudience = targetAudience,
                                    language = language,
                                    tense = tense,
                                    targetPlatform = targetPlatform
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterSection(
    chapters: List<ChapterEntity>,
    onAddChapter: () -> Unit,
    onEditChapter: (Int) -> Unit,
    onDeleteChapter: (ChapterEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Button(
            onClick = onAddChapter,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("add_chapter_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Tambah Bab Baru")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (chapters.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada bab tersimpan. Mulai tulis bab pertama Anda!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(chapters, key = { it.id }) { chapter ->
                    val dateFormatted = remember(chapter.updatedAt) {
                        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                        sdf.format(Date(chapter.updatedAt))
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onEditChapter(chapter.id) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Bab ${chapter.chapterNumber}: ${chapter.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Diperbarui: $dateFormatted",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (chapter.content.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = chapter.content,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                    )
                                }
                            }

                            Row {
                                IconButton(onClick = { onEditChapter(chapter.id) }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Bab",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { onDeleteChapter(chapter) }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus Bab",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CharacterSection(
    characters: List<CharacterEntity>,
    onAddCharacter: () -> Unit,
    onEditCharacter: (Int) -> Unit,
    onDeleteCharacter: (CharacterEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Button(
            onClick = onAddCharacter,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("add_character_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Tambah Karakter")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (characters.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada profil karakter tersimpan.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(characters, key = { it.id }) { character ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onEditCharacter(character.id) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = character.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (!character.alias.isNullOrBlank()) {
                                    Text(
                                        text = "Alias: ${character.alias}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = character.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row {
                                IconButton(onClick = { onEditCharacter(character.id) }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Karakter",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { onDeleteCharacter(character) }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus Karakter",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WorldSection(
    worldEntries: List<WorldEntity>,
    onAddWorld: () -> Unit,
    onEditWorld: (Int) -> Unit,
    onDeleteWorld: (WorldEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Button(
            onClick = onAddWorld,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("add_world_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Tambah Catatan Dunia")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (worldEntries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada catatan legenda, timeline, atau world building.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(worldEntries, key = { it.id }) { entry ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onEditWorld(entry.id) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = entry.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = entry.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row {
                                IconButton(onClick = { onEditWorld(entry.id) }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Catatan",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { onDeleteWorld(entry) }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus Catatan",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContextProfileSection(
    project: ProjectEntity?,
    onSave: (String, String, String, String, String, String, String, String, String) -> Unit
) {
    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    // Local state for the form, initialized from the current project fields
    var genre by remember(project) { mutableStateOf(project.genre) }
    var subGenre by remember(project) { mutableStateOf(project.subGenre) }
    var tone by remember(project) { mutableStateOf(project.tone) }
    var writingStyle by remember(project) { mutableStateOf(project.writingStyle) }
    var pov by remember(project) { mutableStateOf(project.pov) }
    var targetAudience by remember(project) { mutableStateOf(project.targetAudience) }
    var language by remember(project) { mutableStateOf(project.language) }
    var tense by remember(project) { mutableStateOf(project.tense) }
    var targetPlatform by remember(project) { mutableStateOf(project.targetPlatform) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Profil Konteks Cerita",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Profil ini akan disisipkan secara otomatis ke dalam instruksi sistem AI untuk menjaga konsistensi gaya penulisan novel Anda.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = genre,
                            onValueChange = { genre = it },
                            label = { Text("Genre Utama") },
                            placeholder = { Text("Contoh: Fantasy, Sci-Fi, Romance") },
                            modifier = Modifier.fillMaxWidth().testTag("context_genre_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = subGenre,
                            onValueChange = { subGenre = it },
                            label = { Text("Sub-Genre") },
                            placeholder = { Text("Contoh: Dark Fantasy, Space Opera, Slow Burn") },
                            modifier = Modifier.fillMaxWidth().testTag("context_subgenre_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = tone,
                            onValueChange = { tone = it },
                            label = { Text("Tone / Suasana") },
                            placeholder = { Text("Contoh: Gelap, Ceria, Melankolis, Serius") },
                            modifier = Modifier.fillMaxWidth().testTag("context_tone_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = writingStyle,
                            onValueChange = { writingStyle = it },
                            label = { Text("Gaya Penulisan") },
                            placeholder = { Text("Contoh: Light Novel Jepang, Deskriptif, Puitis") },
                            modifier = Modifier.fillMaxWidth().testTag("context_style_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = pov,
                            onValueChange = { pov = it },
                            label = { Text("Sudut Pandang (POV)") },
                            placeholder = { Text("Contoh: Orang Pertama (Aku), Orang Ketiga Terbatas") },
                            modifier = Modifier.fillMaxWidth().testTag("context_pov_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = targetAudience,
                            onValueChange = { targetAudience = it },
                            label = { Text("Target Pembaca") },
                            placeholder = { Text("Contoh: Remaja (YA), Dewasa 18+") },
                            modifier = Modifier.fillMaxWidth().testTag("context_audience_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = language,
                            onValueChange = { language = it },
                            label = { Text("Bahasa Penulisan") },
                            placeholder = { Text("Contoh: Indonesia Baku, Indonesia Populer/Santai") },
                            modifier = Modifier.fillMaxWidth().testTag("context_language_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = tense,
                            onValueChange = { tense = it },
                            label = { Text("Tense (Waktu Kejadian)") },
                            placeholder = { Text("Contoh: Present Tense, Past Tense") },
                            modifier = Modifier.fillMaxWidth().testTag("context_tense_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = targetPlatform,
                            onValueChange = { targetPlatform = it },
                            label = { Text("Target Platform") },
                            placeholder = { Text("Contoh: Fizzo, Wattpad, RoyalRoad") },
                            modifier = Modifier.fillMaxWidth().testTag("context_platform_input"),
                            singleLine = true
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        onSave(genre, subGenre, tone, writingStyle, pov, targetAudience, language, tense, targetPlatform)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Profil Konteks berhasil disimpan!")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_context_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Simpan Profil Konteks", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun StoryBibleSection(
    storyBibleEntries: List<StoryBibleEntity>,
    onAddStoryBible: () -> Unit,
    onEditStoryBible: (Int) -> Unit,
    onDeleteStoryBible: (StoryBibleEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Button(
            onClick = onAddStoryBible,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("add_story_bible_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Tambah Aturan / Catatan")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (storyBibleEntries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada aturan, konflik, atau lore utama Alkitab Cerita.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(storyBibleEntries, key = { it.id }) { entry ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onEditStoryBible(entry.id) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = entry.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = entry.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row {
                                IconButton(onClick = { onEditStoryBible(entry.id) }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Alkitab",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { onDeleteStoryBible(entry) }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus Alkitab",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

