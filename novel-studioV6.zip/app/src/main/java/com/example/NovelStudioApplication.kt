package com.example

import android.app.Application
import com.example.data.AppDatabase
import com.example.repository.ChapterRepository
import com.example.repository.CharacterRepository
import com.example.repository.ProjectRepository
import com.example.repository.SettingsRepository
import com.example.repository.WorldRepository
import com.example.repository.AiRepository
import com.example.repository.StoryBibleRepository

class NovelStudioApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    
    val projectRepository by lazy { ProjectRepository(database.projectDao()) }
    val chapterRepository by lazy { ChapterRepository(database.chapterDao(), aiRepository) }
    val characterRepository by lazy { CharacterRepository(database.characterDao()) }
    val worldRepository by lazy { WorldRepository(database.worldDao()) }
    val storyBibleRepository by lazy { StoryBibleRepository(database.storyBibleDao()) }
    val settingsRepository by lazy { SettingsRepository(this) }
    val aiRepository by lazy { AiRepository(settingsRepository) }
    val storyContextComposer by lazy {
        com.example.repository.StoryContextComposer(
            characterRepository,
            worldRepository,
            storyBibleRepository,
            chapterRepository
        )
    }
}
