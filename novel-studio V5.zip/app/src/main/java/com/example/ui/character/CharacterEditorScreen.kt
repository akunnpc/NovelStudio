package com.example.ui.character

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterEditorScreen(
    projectId: Int,
    characterId: Int,
    viewModel: CharacterViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(characterId) {
        viewModel.loadCharacter(characterId)
    }

    val character by viewModel.characterState.collectAsState()

    var name by remember { mutableStateOf("") }
    var alias by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    // Synchronize states
    LaunchedEffect(character) {
        character?.let {
            name = it.name
            alias = it.alias ?: ""
            description = it.description
        } ?: run {
            name = ""
            alias = ""
            description = ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (characterId == -1) "Profil Karakter Baru" else "Edit Profil Karakter",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                viewModel.saveCharacter(
                                    projectId,
                                    characterId,
                                    name,
                                    alias.ifBlank { null },
                                    description
                                ) {
                                    onNavigateBack()
                                }
                            }
                        },
                        enabled = name.isNotBlank(),
                        modifier = Modifier.testTag("save_character_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Simpan")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nama Karakter") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("character_name_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = alias,
                onValueChange = { alias = it },
                label = { Text("Alias / Julukan (Opsional)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("character_alias_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Deskripsi / Peran / Latar Belakang Karakter") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 250.dp)
                    .testTag("character_desc_input"),
                singleLine = false,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}
