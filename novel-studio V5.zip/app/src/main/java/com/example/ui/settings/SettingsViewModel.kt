package com.example.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: SettingsRepository
) : ViewModel() {

    val apiKey: StateFlow<String> = repository.apiKey
    val baseUrl: StateFlow<String> = repository.baseUrl
    val modelName: StateFlow<String> = repository.modelName

    fun saveSettings(key: String, url: String, model: String) {
        viewModelScope.launch {
            repository.saveSettings(key, url, model)
        }
    }
}
