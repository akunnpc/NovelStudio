package com.example.ui.projectdetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChapterEntity
import com.example.data.CharacterEntity
import com.example.data.ProjectEntity
import com.example.data.WorldEntity
import com.example.data.StoryBibleEntity
import com.example.repository.ChapterRepository
import com.example.repository.CharacterRepository
import com.example.repository.ProjectRepository
import com.example.repository.SettingsRepository
import com.example.repository.WorldRepository
import com.example.repository.AiRepository
import com.example.repository.StoryBibleRepository
import com.example.repository.StoryContextComposer
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ProjectDetailViewModel(
    private val projectRepository: ProjectRepository,
    private val chapterRepository: ChapterRepository,
    private val characterRepository: CharacterRepository,
    private val worldRepository: WorldRepository,
    private val settingsRepository: SettingsRepository,
    private val aiRepository: AiRepository,
    private val storyBibleRepository: StoryBibleRepository,
    private val storyContextComposer: StoryContextComposer
) : ViewModel() {

    private val _projectId = MutableStateFlow<Int>(-1)

    val project: StateFlow<ProjectEntity?> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(null) else projectRepository.getProjectById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val chapters: StateFlow<List<ChapterEntity>> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(emptyList()) else chapterRepository.getChaptersForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val characters: StateFlow<List<CharacterEntity>> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(emptyList()) else characterRepository.getCharactersForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val worldEntries: StateFlow<List<WorldEntity>> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(emptyList()) else worldRepository.getWorldEntriesForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val storyBibleEntries: StateFlow<List<StoryBibleEntity>> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(emptyList()) else storyBibleRepository.getStoryBibleForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aiApiKey: StateFlow<String> = settingsRepository.apiKey
    val aiBaseUrl: StateFlow<String> = settingsRepository.baseUrl
    val aiModelName: StateFlow<String> = settingsRepository.modelName

    // Chat states
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading

    fun setProjectId(id: Int) {
        _projectId.value = id
    }

    fun updateProjectContext(
        genre: String,
        subGenre: String,
        tone: String,
        writingStyle: String,
        pov: String,
        targetAudience: String,
        language: String,
        tense: String,
        targetPlatform: String
    ) {
        val currentProj = project.value ?: return
        viewModelScope.launch {
            val updated = currentProj.copy(
                genre = genre,
                subGenre = subGenre,
                tone = tone,
                writingStyle = writingStyle,
                pov = pov,
                targetAudience = targetAudience,
                language = language,
                tense = tense,
                targetPlatform = targetPlatform
            )
            projectRepository.updateProject(updated)
        }
    }

    fun deleteChapter(chapter: ChapterEntity) {
        viewModelScope.launch {
            chapterRepository.deleteChapter(chapter)
        }
    }

    fun deleteCharacter(character: CharacterEntity) {
        viewModelScope.launch {
            characterRepository.deleteCharacter(character)
        }
    }

    fun deleteWorldEntry(worldEntry: WorldEntity) {
        viewModelScope.launch {
            worldRepository.deleteWorldEntry(worldEntry)
        }
    }

    fun deleteStoryBibleEntry(entry: StoryBibleEntity) {
        viewModelScope.launch {
            storyBibleRepository.deleteStoryBible(entry)
        }
    }

    fun sendChatMessage(message: String) {
        if (message.isBlank()) return

        val userMessage = ChatMessage(role = "user", content = message)
        _chatHistory.value = _chatHistory.value + userMessage
        _isAiLoading.value = true

        val currentProj = project.value
        val contextPrompt = if (currentProj != null) {
            val builder = java.lang.StringBuilder()
            builder.append("Identitas dasar novel/cerita ini:\n")
            if (!currentProj.genre.isNullOrBlank()) builder.append("- Genre: ${currentProj.genre}\n")
            if (!currentProj.subGenre.isNullOrBlank()) builder.append("- Sub Genre: ${currentProj.subGenre}\n")
            if (!currentProj.tone.isNullOrBlank()) builder.append("- Tone/Suasana: ${currentProj.tone}\n")
            if (!currentProj.writingStyle.isNullOrBlank()) builder.append("- Gaya Penulisan: ${currentProj.writingStyle}\n")
            if (!currentProj.pov.isNullOrBlank()) builder.append("- Sudut Pandang (POV): ${currentProj.pov}\n")
            if (!currentProj.targetAudience.isNullOrBlank()) builder.append("- Target Pembaca: ${currentProj.targetAudience}\n")
            if (!currentProj.language.isNullOrBlank()) builder.append("- Bahasa Penulisan: ${currentProj.language}\n")
            if (!currentProj.tense.isNullOrBlank()) builder.append("- Tense (Waktu): ${currentProj.tense}\n")
            if (!currentProj.targetPlatform.isNullOrBlank()) builder.append("- Target Platform: ${currentProj.targetPlatform}\n")
            builder.toString()
        } else {
            ""
        }

        viewModelScope.launch {
            val storyMemory = storyContextComposer.composeStoryMemory(_projectId.value, message)

            val systemInst = buildString {
                append("Anda adalah asisten AI Novel Studio, asisten kreatif penulisan cerita berbahasa Indonesia.")
                if (contextPrompt.isNotEmpty()) {
                    append("\n\n")
                    append(contextPrompt)
                }
                if (storyMemory.isNotEmpty()) {
                    append("\n\n")
                    append(storyMemory)
                }
            }

            val response = aiRepository.generateStoryResponse(message, systemInst)
            _chatHistory.value = _chatHistory.value + ChatMessage(role = "assistant", content = response)
            _isAiLoading.value = false
        }
    }

    fun clearChat() {
        _chatHistory.value = emptyList()
    }
}

data class ChatMessage(
    val role: String, // "user" atau "assistant"
    val content: String
)
