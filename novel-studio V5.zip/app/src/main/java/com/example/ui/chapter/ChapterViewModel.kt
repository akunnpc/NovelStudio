package com.example.ui.chapter

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChapterEntity
import com.example.repository.ChapterRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChapterViewModel(
    private val chapterRepository: ChapterRepository
) : ViewModel() {

    private val _chapterState = MutableStateFlow<ChapterEntity?>(null)
    val chapterState: StateFlow<ChapterEntity?> = _chapterState

    private val _isSaved = MutableStateFlow(false)
    val isSaved: StateFlow<Boolean> = _isSaved

    fun loadChapter(chapterId: Int) {
        if (chapterId == -1) {
            _chapterState.value = null
            _isSaved.value = false
            return
        }
        viewModelScope.launch {
            chapterRepository.getChapterById(chapterId).collect { chapter ->
                _chapterState.value = chapter
            }
        }
    }

    fun saveChapter(projectId: Int, chapterId: Int, title: String, content: String, onDone: () -> Unit) {
        viewModelScope.launch {
            if (chapterId == -1) {
                val maxNum = chapterRepository.getMaxChapterNumber(projectId) ?: 0
                val nextNum = maxNum + 1
                val newChapter = ChapterEntity(
                    projectId = projectId,
                    chapterNumber = nextNum,
                    title = title.ifBlank { "Bab $nextNum" },
                    content = content,
                    updatedAt = System.currentTimeMillis()
                )
                chapterRepository.insertChapter(newChapter)
            } else {
                val existing = _chapterState.value
                if (existing != null) {
                    val updated = existing.copy(
                        title = title,
                        content = content,
                        updatedAt = System.currentTimeMillis()
                    )
                    chapterRepository.updateChapter(updated)
                }
            }
            _isSaved.value = true
            onDone()
        }
    }
}
