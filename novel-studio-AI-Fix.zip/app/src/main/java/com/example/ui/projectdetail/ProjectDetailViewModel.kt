package com.example.ui.projectdetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChapterEntity
import com.example.data.CharacterEntity
import com.example.data.ProjectEntity
import com.example.data.WorldEntity
import com.example.repository.ChapterRepository
import com.example.repository.CharacterRepository
import com.example.repository.ProjectRepository
import com.example.repository.SettingsRepository
import com.example.repository.WorldRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ProjectDetailViewModel(
    private val projectRepository: ProjectRepository,
    private val chapterRepository: ChapterRepository,
    private val characterRepository: CharacterRepository,
    private val worldRepository: WorldRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _projectId = MutableStateFlow<Int>(-1)

    val project: StateFlow<ProjectEntity?> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(null) else projectRepository.getProjectById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val chapters: StateFlow<List<ChapterEntity>> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(emptyList()) else chapterRepository.getChaptersForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val characters: StateFlow<List<CharacterEntity>> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(emptyList()) else characterRepository.getCharactersForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val worldEntries: StateFlow<List<WorldEntity>> = _projectId
        .flatMapLatest { id ->
            if (id == -1) flowOf(emptyList()) else worldRepository.getWorldEntriesForProject(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aiApiKey: StateFlow<String> = settingsRepository.apiKey
    val aiBaseUrl: StateFlow<String> = settingsRepository.baseUrl
    val aiModelName: StateFlow<String> = settingsRepository.modelName

    // Chat states
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading

    fun setProjectId(id: Int) {
        _projectId.value = id
    }

    fun deleteChapter(chapter: ChapterEntity) {
        viewModelScope.launch {
            chapterRepository.deleteChapter(chapter)
        }
    }

    fun deleteCharacter(character: CharacterEntity) {
        viewModelScope.launch {
            characterRepository.deleteCharacter(character)
        }
    }

    fun deleteWorldEntry(worldEntry: WorldEntity) {
        viewModelScope.launch {
            worldRepository.deleteWorldEntry(worldEntry)
        }
    }

    fun sendChatMessage(message: String) {
        val key = aiApiKey.value
        val url = aiBaseUrl.value
        val model = aiModelName.value
        if (message.isBlank()) return

        val userMessage = ChatMessage(role = "user", content = message)
        _chatHistory.value = _chatHistory.value + userMessage
        _isAiLoading.value = true

        viewModelScope.launch {
            val response = callCustomAI(message, key, url, model)
            _chatHistory.value = _chatHistory.value + ChatMessage(role = "assistant", content = response)
            _isAiLoading.value = false
        }
    }

    fun clearChat() {
        _chatHistory.value = emptyList()
    }

    private suspend fun callCustomAI(prompt: String, apiKey: String, baseUrl: String, modelName: String): String {
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val client = OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build()

                val isGemini = baseUrl.contains("googleapis.com") || modelName.startsWith("gemini")

                val endpoint = if (isGemini) {
                    val baseWithSlash = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
                    "${baseWithSlash}models/${modelName}:generateContent?key=${apiKey}"
                } else {
                    val baseWithSlash = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
                    "${baseWithSlash}chat/completions"
                }

                val jsonPayload = if (isGemini) {
                    JSONObject().apply {
                        put("contents", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("parts", org.json.JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("text", prompt)
                                    })
                                })
                            })
                        })
                        put("systemInstruction", JSONObject().apply {
                            put("parts", org.json.JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", "Anda adalah asisten AI Novel Studio, asisten kreatif penulisan cerita berbahasa Indonesia.")
                                })
                            })
                        })
                    }.toString()
                } else {
                    JSONObject().apply {
                        put("model", modelName)
                        put("messages", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("role", "system")
                                put("content", "Anda adalah asisten AI Novel Studio, asisten kreatif penulisan cerita berbahasa Indonesia.")
                            })
                            put(JSONObject().apply {
                                put("role", "user")
                                put("content", prompt)
                            })
                        })
                    }.toString()
                }

                val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
                val requestBody = jsonPayload.toRequestBody(mediaType)

                val requestBuilder = Request.Builder()
                    .url(endpoint)
                    .addHeader("Content-Type", "application/json")
                
                if (!isGemini && apiKey.isNotBlank()) {
                    requestBuilder.addHeader("Authorization", "Bearer $apiKey")
                }

                val request = requestBuilder.post(requestBody).build()

                client.newCall(request).execute().use { response ->
                    val bodyString = response.body?.string()
                    if (response.isSuccessful && bodyString != null) {
                        if (isGemini) {
                            val json = JSONObject(bodyString)
                            val candidates = json.getJSONArray("candidates")
                            val firstCandidate = candidates.getJSONObject(0)
                            val contentObj = firstCandidate.getJSONObject("content")
                            val parts = contentObj.getJSONArray("parts")
                            parts.getJSONObject(0).getString("text")
                        } else {
                            val json = JSONObject(bodyString)
                            val choices = json.getJSONArray("choices")
                            val message = choices.getJSONObject(0).getJSONObject("message")
                            message.getString("content")
                        }
                    } else {
                        "Error ${response.code}: ${response.message}\nDetail: $bodyString"
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                "Gagal terhubung dengan API: ${e.localizedMessage ?: "Unknown Error"}"
            }
        }
    }
}

data class ChatMessage(
    val role: String, // "user" atau "assistant"
    val content: String
)
