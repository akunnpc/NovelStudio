package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE projectId = :projectId ORDER BY chapterNumber ASC")
    fun getChaptersForProject(projectId: Int): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE id = :id")
    fun getChapterById(id: Int): Flow<ChapterEntity?>

    @Query("SELECT * FROM chapters WHERE id = :id")
    suspend fun getChapterByIdOneShot(id: Int): ChapterEntity?

    @Query("SELECT COUNT(*) FROM chapters WHERE projectId = :projectId")
    fun getChapterCountForProject(projectId: Int): Flow<Int>

    @Query("SELECT MAX(chapterNumber) FROM chapters WHERE projectId = :projectId")
    suspend fun getMaxChapterNumber(projectId: Int): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Delete
    suspend fun deleteChapter(chapter: ChapterEntity)
}
