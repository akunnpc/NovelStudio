package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectEntity
import com.example.data.ProjectWithCount
import com.example.repository.ProjectRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: ProjectRepository) : ViewModel() {

    val projects: StateFlow<List<ProjectWithCount>> = repository.allProjectsWithCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addProject(title: String, coverImageUri: String?, totalChapterTarget: Int) {
        viewModelScope.launch {
            repository.insertProject(
                ProjectEntity(
                    title = title,
                    coverImageUri = coverImageUri,
                    totalChapterTarget = if (totalChapterTarget <= 0) 1 else totalChapterTarget
                )
            )
        }
    }

    fun deleteProject(id: Int) {
        viewModelScope.launch {
            val project = repository.getProjectByIdOneShot(id)
            if (project != null) {
                repository.deleteProject(project)
            }
        }
    }
}
