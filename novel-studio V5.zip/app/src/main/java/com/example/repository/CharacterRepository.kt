package com.example.repository

import com.example.data.CharacterDao
import com.example.data.CharacterEntity
import kotlinx.coroutines.flow.Flow

class CharacterRepository(private val characterDao: CharacterDao) {
    fun getCharactersForProject(projectId: Int): Flow<List<CharacterEntity>> =
        characterDao.getCharactersForProject(projectId)

    fun getChapterById(id: Int): Flow<CharacterEntity?> = characterDao.getCharacterById(id) // Note: this query matches the original CharacterDao.getCharacterById

    fun getCharacterById(id: Int): Flow<CharacterEntity?> = characterDao.getCharacterById(id)

    suspend fun getCharacterByIdOneShot(id: Int): CharacterEntity? = characterDao.getCharacterByIdOneShot(id)

    suspend fun insertCharacter(character: CharacterEntity): Long = characterDao.insertCharacter(character)

    suspend fun updateCharacter(character: CharacterEntity) = characterDao.updateCharacter(character)

    suspend fun deleteCharacter(character: CharacterEntity) = characterDao.deleteCharacter(character)
}
