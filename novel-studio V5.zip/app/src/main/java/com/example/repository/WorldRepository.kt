package com.example.repository

import com.example.data.WorldDao
import com.example.data.WorldEntity
import kotlinx.coroutines.flow.Flow

class WorldRepository(private val worldDao: WorldDao) {
    fun getWorldEntriesForProject(projectId: Int): Flow<List<WorldEntity>> =
        worldDao.getWorldEntriesForProject(projectId)

    fun getWorldEntryById(id: Int): Flow<WorldEntity?> = worldDao.getWorldEntryById(id)

    suspend fun getWorldEntryByIdOneShot(id: Int): WorldEntity? = worldDao.getWorldEntryByIdOneShot(id)

    suspend fun insertWorldEntry(worldEntry: WorldEntity): Long = worldDao.insertWorldEntry(worldEntry)

    suspend fun updateWorldEntry(worldEntry: WorldEntity) = worldDao.updateWorldEntry(worldEntry)

    suspend fun deleteWorldEntry(worldEntry: WorldEntity) = worldDao.deleteWorldEntry(worldEntry)
}
