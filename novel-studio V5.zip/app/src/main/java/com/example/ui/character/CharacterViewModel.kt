package com.example.ui.character

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CharacterEntity
import com.example.repository.CharacterRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CharacterViewModel(
    private val repository: CharacterRepository
) : ViewModel() {

    private val _characterState = MutableStateFlow<CharacterEntity?>(null)
    val characterState: StateFlow<CharacterEntity?> = _characterState

    fun loadCharacter(characterId: Int) {
        if (characterId == -1) {
            _characterState.value = null
            return
        }
        viewModelScope.launch {
            repository.getCharacterById(characterId).collect { character ->
                _characterState.value = character
            }
        }
    }

    fun saveCharacter(projectId: Int, characterId: Int, name: String, alias: String?, description: String, onDone: () -> Unit) {
        viewModelScope.launch {
            if (characterId == -1) {
                val newCharacter = CharacterEntity(
                    projectId = projectId,
                    name = name,
                    alias = alias,
                    description = description
                )
                repository.insertCharacter(newCharacter)
            } else {
                val existing = _characterState.value
                if (existing != null) {
                    val updated = existing.copy(
                        name = name,
                        alias = alias,
                        description = description
                    )
                    repository.updateCharacter(updated)
                }
            }
            onDone()
        }
    }
}
